document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const form = document.getElementById('resume-form');
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const phoneInput = document.getElementById('phone');
  const locationInput = document.getElementById('location');
  const profileInput = document.getElementById('profile');

  const educationList = document.getElementById('education-list');
  const addEducationBtn = document.getElementById('add-education');

  const skillsCheckboxes = document.querySelectorAll('.skills-checkboxes input[type="checkbox"]');

  const experienceList = document.getElementById('experience-list');
  const addExperienceBtn = document.getElementById('add-experience');

  const clearFormBtn = document.getElementById('clear-form');

  // Preview elements
  const previewName = document.getElementById('preview-name');
  const previewEmail = document.getElementById('preview-email');
  const previewPhone = document.getElementById('preview-phone');
  const previewLocation = document.getElementById('preview-location');
  const previewProfile = document.getElementById('preview-profile');
  const previewEducation = document.getElementById('preview-education');
  const previewSkills = document.getElementById('preview-skills');
  const previewExperience = document.getElementById('preview-experience');

  // Initialize education and experience count
  let educationCount = 0;
  let experienceCount = 0;

  // Update preview function
  function updatePreview() {
    previewName.textContent = nameInput.value || 'Your Name';
    previewEmail.textContent = emailInput.value || 'your.email@example.com';
    previewPhone.textContent = phoneInput.value || '+123 456 7890';
    previewLocation.textContent = locationInput.value || 'City, State';
    previewProfile.textContent = profileInput.value || 'Brief profile summary will appear here.';

    // Update education preview
    previewEducation.innerHTML = '';
    for (let i = 0; i < educationList.children.length; i++) {
      const edRow = educationList.children[i];
      const degree = edRow.querySelector('.edu-degree').value;
      const year = edRow.querySelector('.edu-year').value;
      const school = edRow.querySelector('.edu-school').value;
      if(degree || year || school) {
        const li = document.createElement('li');
        li.textContent = `${year} - ${degree}, ${school}`;
        previewEducation.appendChild(li);
      }
    }

    // Update skills preview
    previewSkills.innerHTML = '';
    skillsCheckboxes.forEach(chk => {
      if(chk.checked) {
        const li = document.createElement('li');
        li.textContent = chk.value;
        previewSkills.appendChild(li);
      }
    });

    // Update experience preview
    previewExperience.innerHTML = '';
    for (let i = 0; i < experienceList.children.length; i++) {
      const expRow = experienceList.children[i];
      const position = expRow.querySelector('.exp-position').value;
      const duration = expRow.querySelector('.exp-duration').value;
      const company = expRow.querySelector('.exp-company').value;
      if(position || duration || company) {
        const li = document.createElement('li');
        li.textContent = `${duration} - ${position}, ${company}`;
        previewExperience.appendChild(li);
      }
    }
  }

  // Add education row
  function addEducationRow() {
    educationCount++;
    const div = document.createElement('div');
    div.classList.add('education-row');
    div.innerHTML = `
      <input type="text" class="edu-degree" placeholder="Degree (e.g. B-Tech in IT)" />
      <input type="text" class="edu-year" placeholder="Year/Duration (e.g. 2022-2026)" />
      <input type="text" class="edu-school" placeholder="School/College" />
      <button type="button" class="remove-education" title="Remove Education">✖</button>
    `;
    educationList.appendChild(div);

    // Remove button listener
    div.querySelector('.remove-education').addEventListener('click', () => {
      div.remove();
      updatePreview();
    });

    // Update on input change
    div.querySelectorAll('input').forEach(input => {
      input.addEventListener('input', updatePreview);
    });
  }

  // Add experience row
  function addExperienceRow() {
    experienceCount++;
    const div = document.createElement('div');
    div.classList.add('experience-row');
    div.innerHTML = `
      <input type="text" class="exp-position" placeholder="Position (e.g. Infosys Intern)" />
      <input type="text" class="exp-duration" placeholder="Duration (e.g. 10/2024-12/2024)" />
      <input type="text" class="exp-company" placeholder="Company" />
      <button type="button" class="remove-experience" title="Remove Experience">✖</button>
    `;
    experienceList.appendChild(div);

    // Remove button listener
    div.querySelector('.remove-experience').addEventListener('click', () => {
      div.remove();
      updatePreview();
    });

    // Update on input change
    div.querySelectorAll('input').forEach(input => {
      input.addEventListener('input', updatePreview);
    });
  }

  // Initial add one row for education and experience
  addEducationRow();
  addExperienceRow();

  // Input event listeners for personal info and profile
  [nameInput, emailInput, phoneInput, locationInput, profileInput].forEach(input => {
    input.addEventListener('input', updatePreview);
  });

  // Skills checkboxes listener
  skillsCheckboxes.forEach(chk => {
    chk.addEventListener('change', updatePreview);
  });

  // Buttons event listeners
  addEducationBtn.addEventListener('click', addEducationRow);
  addExperienceBtn.addEventListener('click', addExperienceRow);

  clearFormBtn.addEventListener('click', () => {
    form.reset();
    educationList.innerHTML = '';
    experienceList.innerHTML = '';
    addEducationRow();
    addExperienceRow();
    updatePreview();
  });

  // Initial preview update
  updatePreview();
});